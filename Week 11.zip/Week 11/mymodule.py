def greeting(name):
    print("hello,"+name)