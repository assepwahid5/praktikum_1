# Konstanta Pi
pi = 3.14

# Fungsi untuk menghitung luas lingkaran
def llingkaran(r):
    return pi * r * r

# Fungsi untuk menghitung luas persegi
def lpersegi(s):
    return s * s

# Fungsi untuk menghitung luas persegi panjang
def lpersegipanjang(p, l):
    return p * l
