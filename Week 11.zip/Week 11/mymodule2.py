person1={
    "name" : "Assep Wahid",
    "age" : 19 ,
    "country" : "Indonesia",
    "motto" : "jika ada yang susah kenapa nyari yang gampang"
}